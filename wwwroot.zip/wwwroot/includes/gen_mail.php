<?php
require "PHPMailer-master/PHPMailerAutoload.php";		
require "PHPMailer-master/class.phpmailer.php";
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded


function sendemail($sTOname,$sTOemail,$sBODY,$sSubject){
	

$mail             = new PHPMailer();



$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "smtp.1and1.com"; // SMTP server
$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "smtp.1and1.com"; // sets the SMTP server
$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
$mail->Username   = "noreply3@miffnaz.org"; // SMTP account username
$mail->Password   = "Spider123";        // SMTP account password

$mail->SetFrom('noreply3@miffnaz.org', 'MiffNaz Portal');

$mail->AddReplyTo("noreply3@miffnaz.org","MiffNaz Portal");

$mail->Subject    = $sSubject;

//$mail->AltBody    = "";
$mail->MsgHTML($sBODY);
$mail->AddAddress($sTOemail, $sTOname);
if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
}


function useremail($iAction_Id,$sData,$dbCon){

	



	$sSqlE1="select adult.name, adult.surname, adult.email, adult.adult_id, user_email.adult_id, user_email.action_id, user_email_actions.action_id, user_email_actions.action_name from adult inner join user_email on adult.adult_id=user_email.adult_id inner join user_email_actions on user_email_actions.action_id=user_email.action_id where user_email.action_id='".$iAction_Id."'";
	$resultE1 = mysqli_query($dbCon,$sSqlE1);
	while($rowE1 = mysqli_fetch_array($resultE1)) {
		
		$mail             = new PHPMailer();
		$mail->IsSMTP(); // telling the class to use SMTP
		$mail->Host       = "smtp.1and1.com"; // SMTP server
		$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
		                                           // 1 = errors and messages
		                                           // 2 = messages only
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->Host       = "smtp.1and1.com"; // sets the SMTP server
		$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
		$mail->Username   = "noreply3@miffnaz.org"; // SMTP account username
		$mail->Password   = "Spider123";        // SMTP account password

		$mail->SetFrom('noreply3@miffnaz.org', 'MiffNaz Portal');

		$mail->AddReplyTo("noreply3@miffnaz.org","MiffNaz Portal");
		$mail->Subject    = $rowE1['action_name'];
		//$mail->AltBody    = "";
		$mail->MsgHTML($sData);
		$sTOname=$rowE1['name']." ".$rowE1['surname'];
		$sTOemail=$rowE1['email'];
		$mail->AddAddress($sTOemail, $sTOname);
		if(!$mail->Send()) {
		  echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		sleep(1);
}
}

?> 
 
