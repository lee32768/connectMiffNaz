<?php
$host="10.10.2.7"; // Host name
$username="miffnaz_web_user"; // Mysql username
$password="dbconnect123"; // Mysql password
$db_name="db533946139"; // Database name
// Connect to server and select databse.
$con=mysqli_connect($host,$username,$password,$db_name);
// Check connection
if (mysqli_connect_errno()) {
	//echo "Failed to connect to MySQL: " . mysqli_connect_error();
} else {
	//echo "connected";
}

if (!$con) {
    $db_connected="False";
} else {
	$db_connected="True";
}

//include mysql sanatize function
function sanatize($svar,$con_db) {
    $svar1 = stripslashes($svar);
	$svar2 = mysqli_real_escape_string($con_db,$svar1);
	$unwanted = array("'"); // add any unwanted char to this array
    $svar3 = str_ireplace($unwanted, '', $svar2);
	return $svar3;
}

?> 
 
