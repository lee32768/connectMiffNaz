<?php


function que_single_sms($sName,$sQueDT,$sFrom,$sTo,$sMsg,$sCampaign,$dbCon){

		$sql="insert into sms_que (name, quedt, sms_from, sms_num, sms_msg, campaign) values ('".$sName."','".$sQueDT."','".$sFrom."','".$sTo."','".$sMsg."','".$sCampaign."')";
		$result = mysqli_query($dbCon,$sql);
		echo $sql;

}
?> 
 
