<?php

function que_mail($sTo,$sFrom,$sSubject,$sBody,$sUser,$dbCon){

		$sql="insert into email_que (sTo, sFrom, sSubject, sBody, sUser) values ('".$sTo."','".$sFrom."','".$sSubject."','".$sBody."','".$sUser."')";
		$result = mysqli_query($dbCon,$sql);


?> 
 
