<?php
require "PHPMailer-master/PHPMailerAutoload.php";		
require "PHPMailer-master/class.phpmailer.php";
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded
session_start();


//				****** Use this function to immediately send an email******
function instant_mail($sTOname,$sTOemail,$sBODY,$sSubject){
	

$mail             = new PHPMailer();



$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "smtp.1and1.com"; // SMTP server
$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "smtp.1and1.com"; // sets the SMTP server
$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
$mail->Username   = "noreply3@miffnaz.org"; // SMTP account username
$mail->Password   = "Spider123";        // SMTP account password

$mail->SetFrom('noreply3@miffnaz.org', 'MiffNaz Portal');

$mail->AddReplyTo("noreply3@miffnaz.org","MiffNaz Portal");

$mail->Subject    = $sSubject;

//$mail->AltBody    = "";
$mail->MsgHTML($sBODY);
$mail->AddAddress($sTOemail, $sTOname);
if(!$mail->Send()) {
  //echo "Mailer Error: " . $mail->ErrorInfo;
  $txt = $mail->ErrorInfo;
  $myfile = file_put_contents('c:\inetpub\wwwroot\logs.txt', $txt.PHP_EOL , FILE_APPEND | LOCK_EX);
} 
}

//				****** Use this function to que and email******
function que_mail($queDT,$sFullname,$sTo,$sFrom,$sSubject,$sBody,$sUser,$sAttachURL,$dbCon){

		if ($queDT==''){
  			$queDT=date("Y-m-d H:i:s");
		}
		if ($sFrom==''){
  			$sFrom="noreply3@miffnaz.org";
		}
		$sqlE2="insert into email_que (queDT,sFullname, sTo, sFrom, sSubject, sBody, sUser, sAttachURL) values ('".$queDT."','".$sFullname."','".$sTo."','".$sFrom."','".$sSubject."','".$sBody."','".$sUser."','".$sAttachURL."')";
				
		
		$result = mysqli_query($dbCon,$sqlE2);
		
}

//				****** Use this function to que an email from a SQL defined table******
function que_sys_mail($iAction_Id,$sData,$dbCon){
	$sSqlE1="select adult.name, adult.surname, adult.email, adult.adult_id, user_email.adult_id, user_email.action_id, user_email_actions.action_id, user_email_actions.action_name from adult inner join user_email on adult.adult_id=user_email.adult_id inner join user_email_actions on user_email_actions.action_id=user_email.action_id where user_email.action_id='".$iAction_Id."'";
	$resultE1 = mysqli_query($dbCon,$sSqlE1);
	while($rowE1 = mysqli_fetch_array($resultE1)) {
		

		
		$sSubject= $rowE1['action_name'];
		$sBody=$sData;
		$sFullname=$rowE1['name']." ".$rowE1['surname'];
		$sTo=$rowE1['email'];
		$sFrom="noreply3@miffnaz.org";
		if (!isset($_SESSION['fullname'])){
  			$_SESSION['fullname'] = "system";
		}
		$queDT=date("Y-m-d H:i:s");
		$sAttachURL='';
		que_mail($queDT,$sFullname,$sTo,$sFrom,$sSubject,$sBody,$_SESSION["fullname"],$sAttachURL,$dbCon);
}
} 



//				****** Use this function to immediately send an email - with an Attachment******
function instant_mail_attachment($sTOname,$sTOemail,$sBODY,$sSubject,$sAttachment){
	

$mail             = new PHPMailer();



$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "smtp.1and1.com"; // SMTP server
$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "smtp.1and1.com"; // sets the SMTP server
$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
$mail->Username   = "noreply3@miffnaz.org"; // SMTP account username
$mail->Password   = "Spider123";        // SMTP account password

$mail->SetFrom('noreply3@miffnaz.org', 'MiffNaz Portal');

$mail->AddReplyTo("noreply3@miffnaz.org","MiffNaz Portal");

$mail->Subject    = $sSubject;

//$mail->AltBody    = "";
$mail->MsgHTML($sBODY);
$mail->AddAttachment($sAttachment);
$mail->AddAddress($sTOemail, $sTOname);
if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} 
}




//				****** Use this function to que an email from a SQL defined table******
/*function que_sys_mail($iAction_Id,$sData,$dbCon){
	$sSqlE1="select adult.name, adult.surname, adult.email, adult.adult_id, user_email.adult_id, user_email.action_id, user_email_actions.action_id, user_email_actions.action_name from adult inner join user_email on adult.adult_id=user_email.adult_id inner join user_email_actions on user_email_actions.action_id=user_email.action_id where user_email.action_id='".$iAction_Id."'";
	$resultE1 = mysqli_query($dbCon,$sSqlE1);
	while($rowE1 = mysqli_fetch_array($resultE1)) {
		
		$mail             = new PHPMailer();
		$mail->IsSMTP(); // telling the class to use SMTP
		$mail->Host       = "smtp.1and1.com"; // SMTP server
		$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
		                                           // 1 = errors and messages
		                                           // 2 = messages only
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->Host       = "smtp.1and1.com"; // sets the SMTP server
		$mail->Port       = 587;                    // set the SMTP port for the GMAIL server
		$mail->Username   = "noreply3@miffnaz.org"; // SMTP account username
		$mail->Password   = "Spider123";        // SMTP account password

		$mail->SetFrom('noreply3@miffnaz.org', 'MiffNaz Portal');

		$mail->AddReplyTo("noreply3@miffnaz.org","MiffNaz Portal");
		$mail->Subject    = $rowE1['action_name'];
		//$mail->AltBody    = "";
		$mail->MsgHTML($sData);
		$sTOname=$rowE1['name']." ".$rowE1['surname'];
		$sTOemail=$rowE1['email'];
		$mail->AddAddress($sTOemail, $sTOname);
		if(!$mail->Send()) {
		  echo "Mailer Error: " . $mail->ErrorInfo;
		} 
		sleep(1);
}
} */

?> 
 
