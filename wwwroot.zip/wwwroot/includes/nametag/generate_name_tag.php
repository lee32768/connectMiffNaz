<?php
require('fpdf/fpdf.php');


			


$f=0;  //1= frame for troubleshooting 0=no frame for production
$pdf = new FPDF('L','mm',array(62,100));
//$pdf = new FPDF('P','pt');
//$pdf->AddPage('P','Letter');
$pdf->SetMargins(8,1,1);
$pdf->AddPage();
$pdf->SetAutoPageBreak('FALSE');


$pdf->Image($_SESSION['tag_logo'],4,4,25);
if ($_SESSION['tag_aux_logo']<>""){
	$pdf->Image($_SESSION['tag_aux_logo'],8,50,10);	
}



$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,6,$_SESSION['tag_header'],$f,1,'R');

$pdf->Cell(0,12," ",$f,1,'C');

$pdf->SetFont('Arial','B',36);
$pdf->Cell(0,12,$_SESSION['tag_name'],$f,1,'C');
$pdf->Cell(0,5," ",$f,1,'C');
$pdf->Cell(0,12,$_SESSION['tag_surname'],$f,1,'C');

$pdf->Cell(0,8," ",$f,1,'C');

$pdf->SetFont('Arial','B',10);
$pdf->Cell(0,5,$_SESSION['tag_footer'],$f,1,'R');


$tagfilename=$_SESSION['tag_name']." ".$_SESSION['tag_surname'].".pdf";




$pdf->Output('D',$tagfilename);

?>