<?php
require 'includes/db_connect.php';
require 'includes/mail_functions.php';

header('Content-Type: application/json');


$msg="zoinks!";
$update_response = file_get_contents("php://input");
$update = json_decode($update_response, true);
if (isset($update["queryResult"]["action"])) {
    processMessage($update,$con);
}

	


function processMessage($update,$con) {
			
		//song request Intent
		if($update["queryResult"]["action"]=="request_song"){
			header('Content-Type: application/json');
			$songname= sanatize($update["queryResult"]["parameters"]["any"],$con);
				$req_dump = print_r( $update, true );
				$fp = file_put_contents( 'breesebot_convos.log', $req_dump);

        	//look for the source - ie a mobile number
        	if (isset($update["queryResult"]["outputContexts"]["0"]["parameters"]["twilio_sender_id"])) {		
    			$phonenum = substr($update["queryResult"]["outputContexts"]["0"]["parameters"]["twilio_sender_id"],2);
    			$sql="SELECT name, surname, sms_num from adult where adult.sms_num='".$phonenum."'";	
    			$result = mysqli_query($con,$sql);
    			$row = mysqli_fetch_array($result);
    			$name = " ".$row['name'];
    			$surname = $row['surname'];
    			$fullname = $row['name']." ".$row['surname'];
    			    			
			} else {
				$name = "";
			}
			
			
			
			//send a response message
			$msg= "Sure thing".$name.".  I'll forward your request to sing ". $songname.".  Have a great day!";						
			header('Content-Type: application/json');
			$response = new stdClass;
			$response->fulfillmentText = $msg;
        	echo json_encode($response); 
        	
        	//send email to users
        	if ($row['name']==""){
        		if ($phonenum==""){
				$campmsg = "A web agent has requested the song: ".$songname;		
				} else {
				$campmsg = "The caller at number ".$phonenum." has requested the song: ".$songname;		
				}
			} else {
				$campmsg = $name." ".$surname." has requested the song: ".$songname;
			}        	
        	que_mail("","Lee Snook","lee65536@gmail.com","","A song has been requested.",$campmsg,"system","",$con);
        	que_mail("","Wayne Krell","waynekrell@miffnaz.org","","A song has been requested.",$campmsg,"system","",$con);
     	
        	
			
			
			
		}

		





		
		
	
       
       
    }   
    




?>