<?php
       
    exec('wmic cpu get LoadPercentage', $p);
   	echo $p[1];



?>