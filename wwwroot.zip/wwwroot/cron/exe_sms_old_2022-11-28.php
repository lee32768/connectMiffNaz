<?php
require_once 'db_connect.php';


    // Include the Twilio PHP library, sid and token
    use Twilio\Rest\Client; 
    require "twilio-php-master/twilio-php-master/Twilio/autoload.php";
    $sid = 'ACe5a886c519d2e5ac8ac66dd175393857';
    $token = 'bf8ab68fcd6123a72d602cdc2627943e';
    $client = new Client($sid, $token);
    

				$rounded_now = date("Y-m-d H:i:s");
				$sSql = "SELECT * FROM sms_que WHERE queDT < '".$rounded_now."' Limit 10";
				//echo $sSql;
				$result1 = mysqli_query($con,$sSql);
					while($row1 = mysqli_fetch_array($result1)) {
						$sms_num="+1".$row1['sms_num'];
						$sms_msg=$row1['sms_msg'];						
						if($row1['sms_from']=='0'){
							$sms_from="+15709660852";
						} else {
							$sms_from="+".$row1['sms_from'];
						}
						$client->messages
							    ->create(
							        $sms_num,
							        array(
							            "from" => $sms_from,
							            "body" => $sms_msg
							        )
							    );
						
						sleep(1);	
							//$sSql2="insert into email_log (queDT,sFullname,sTo,sFrom,sSubject,sBody,sAttachURL,sUser) values ('".$row1['queDT']."','".$sTOname."','".$sTOemail."','".$row1['sFrom']."','".$sSubject."','".$sBODY."','".$row1['sAttachURL']."','".$row1['sUser']."')";	
							//mysqli_query($con,$sSql2);
							//echo $sSql2;
								$sSql3="delete from sms_que where id='".$row1['id']."'";	
								mysqli_query($con,$sSql3);
								//echo $sSql3;
						//echo "email sent ";	
					}	
?>
