<?php
session_start(); 
   	   	$host="localhost"; // Host name
		$username="dbo533946139"; // Mysql username
		$password="Aardvark123"; // Mysql password
		$db_name="db533946139"; // Database name

$con=mysqli_connect($host,$username,$password,$db_name);

//look for relays to turn on first
$sql1="SELECT count(*) as 'num' from security_que where unix_timestamp(NOW()) > unix_timestamp(open)";
echo $sql1."<br>";
$result1 = mysqli_query($con,$sql1);
$row1 = mysqli_fetch_assoc($result1);
$num = $row1['num'];
echo $num;

if ($num>0){
		//turn on relays by url
	$sql="SELECT on_url from security_que where unix_timestamp(NOW()) < unix_timestamp(close)";
	$result = mysqli_query($con,$sql);
		while($row = mysqli_fetch_array($result)) {
			$ch = curl_init($row['on_url']);
			curl_exec($ch);
			curl_close($ch);
			sleep(2);
		}
		//turn off relays by url
	$sql3="SELECT id, off_url from security_que where unix_timestamp(NOW()) >= unix_timestamp(close)";
	$result3 = mysqli_query($con,$sql3);
		while($row3 = mysqli_fetch_array($result3)) {
			$ch = curl_init($row3['off_url']);
			curl_exec($ch);
			curl_close($ch);
			sleep(2);
		//move record to log file
		$sql5="insert into security_log (id, inistamp, event_id, user, door, open, close, name, description, on_url, off_url) select id, inistamp, event_id, user, door, open, close, name, description, on_url, off_url from security_que where id = '".$row3['id']."'";	
		echo "<br>".$sql5;
		$result5 = mysqli_query($con,$sql5);	
		//delete record 
		$sql4="delete from security_que where id='".$row3['id']."'";
		$result4 = mysqli_query($con,$sql4);			
		}

} else {
	//if nothing scheduled - turn off all relays
//	$ch = curl_init("http://10.10.13.10/30000/44");
//	curl_exec($ch);
//	curl_close($ch);
}

?>