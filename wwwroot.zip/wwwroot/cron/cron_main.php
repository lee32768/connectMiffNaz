<?php
     //you need to set is_user to admin privliages for this functin to work  
    exec('wmic cpu get LoadPercentage', $p);
   	echo $p[1];

	if ((int)$p<50){
		include 'c:\inetpub\wwwroot\cron\que_email.php';
		sleep(1);
		include 'c:\inetpub\wwwroot\cron\exe_sms.php';
		sleep(1);
		include 'c:\inetpub\wwwroot\cron\exe_voice.php';
	}


?>