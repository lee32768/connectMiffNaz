<?php
require_once 'db_connect.php';

    use Twilio\Rest\Client; 
    require_once "twilio-php-master/twilio-php-master/Twilio/autoload.php";

    $sid = 'ACe5a886c519d2e5ac8ac66dd175393857';
    $token = 'bf8ab68fcd6123a72d602cdc2627943e';
    
    $client = new Client($sid, $token);
 

 




$sql="SELECT id, name, unix_timestamp(quedt) as quedt, voice_num, url, attempts, prelude_machine, amd, status from phonetree_que";
//echo $sql."<br>";
$result = mysqli_query($con,$sql);

$number[0]='';
$name[0]='';
$url[0]='';
$quedt[0]='';
$id[0]='';
$attempts[0]=0;
$phonetree[0]=0;
$prelude_mach[0]=0;
$amd[0]=0;
$status[0]='';
$num_texts=0;
$rightnow=time();


while($row = mysqli_fetch_array($result)) {
	$number[$num_texts]=$row['voice_num'];
	$name[$num_texts]=$row['name'];
	$id[$num_texts]=$row['id'];
	$url[$num_texts]=$row['url'];
	$prelude_mach[$num_texts]=$row['prelude_machine'];	
	$attempts[$num_texts]=$row['attempts'];
	$quedt[$num_texts]=$row['quedt'];
	$amd[$num_texts]=$row['amd'];
	$status[$num_texts]=$row['status'];
	$num_texts=$num_texts+1;	
}


	for ($x = 0; $x < $num_texts; $x++) { 
		
  		//$call = $client->account->calls->create("+15704150362", $number[$x], "http://www.miffnaz.org/phonetree/playmessage.php?url=".$_POST["selectedurl"], array());
 	//if($quedt[$x]<$rightnow and $attempts[$x]<3){
 	  if (($quedt[$x]<$rightnow and $attempts[$x]=="0" and $status[$x]=="") or (($quedt[$x]+900)<$rightnow and $attempts[$x]=="1" and $status[$x]=="") or (($quedt[$x]+1800)<$rightnow and $attempts[$x]=="2" and $status[$x]=="")){
 		//if ($amd[$x]==1){
 		/*echo $rightnow;
 		echo "<br>"	;
		echo $quedt[$x];
		echo "<br>"	;
		echo $quedt[$x]+900;
		echo "<br>"	;
		echo $quedt[$x]+1800;
		echo "<br>"	;
		echo $attempts[$x];*/
		//$call = $client->account->calls->create("+15709660852", $number[$x], "http://www.miffnaz.org/phonetree/playmessage.php?url=".$url[$x]."&premachine=".$prelude_mach[$x]."&amd=".$amd[$x], array('IfMachine' =>'Continue', "Method" => "GET","StatusCallback" => "http://www.miffnaz.org/phonetree/statuscallback.php","StatusCallbackMethod" => "POST","StatusCallbackEvent" => array("initiated","completed")));
		//$call = $client->calls->create($number[$x],"+15709660852",array("url" => "http://www.miffnaz.org/phonetree/playmessage.php?url=".$url[$x]."&premachine=".$prelude_mach[$x]."&amd=".$amd[$x]));
	
    	//} else {
		//$call = $client->account->calls->create("+15709660852", $number[$x], "http://www.miffnaz.org/phonetree/playmessage.php?url=".$url[$x]."&premachine=".$prelude_mach[$x]."&amd=".$amd[$x], array("Method" => "GET","StatusCallback" => "http://www.miffnaz.org/phonetree/statuscallback.php","StatusCallbackMethod" => "POST","StatusCallbackEvent" => array("initiated","completed")));
		
		$call = $client->calls->create($number[$x],"+15709660852",array("url" => "http://www.miffnaz.org/phonetree/playmessage.php?url=".$url[$x]."&premachine=".$prelude_mach[$x]."&amd=".$amd[$x],"StatusCallback" => "http://www.connect.miffnaz.org/main/naznotify/statuscallback.php","StatusCallbackMethod" => "POST","StatusCallbackEvent" => array("initiated","completed")));	
		//}
    	
    	$ssql2="update phonetree_que set status='Sent to Twilio' where id='".$id[$x]."'";
        $result2 = mysqli_query($con,$ssql2);
		}
 		
        // Display a confirmation message on the screen
        //$ssql2="insert into phonetree_que (name, quedt, voice_num, url) values ('".$name[$x]."','".$_POST['queDT']."','".$number[$x]."','".$_POST["selectedurl"]."')";
        //$result2 = mysqli_query($con,$ssql2);
        //echo $x." Message in que for ".$name[$x]." at ".$_POST['queDT'];
        //echo "<br>";
        
        
        
    }

    
    
    ?>
    