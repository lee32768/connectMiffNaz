<?php
require 'db_connect.php';
require 'mail_functions.php';

				$sSql="SELECT * FROM email_que ORDER by queDT ASC LIMIT 5";
				$result1 = mysqli_query($con,$sSql);
					while($row1 = mysqli_fetch_array($result1)) {
						$sTOname=$row1['sFullname'];
						$sTOemail=$row1['sTo'];
						$sBODY=$row1['sBody'];
						$sSubject=$row1['sSubject'];
						instant_mail($sTOname,$sTOemail,$sBODY,$sSubject);
						sleep(1);	
							$sSql2="insert into email_log (queDT,sFullname,sTo,sFrom,sSubject,sBody,sAttachURL,sUser) values ('".$row1['queDT']."','".$sTOname."','".$sTOemail."','".$row1['sFrom']."','".$sSubject."','".$sBODY."','".$row1['sAttachURL']."','".$row1['sUser']."')";	
							mysqli_query($con,$sSql2);
							//echo $sSql2;
								$sSql3="delete from email_que where id='".$row1['id']."'";	
								mysqli_query($con,$sSql3);
								//echo $sSql3;
						//echo "email sent ";	
					}	
?>