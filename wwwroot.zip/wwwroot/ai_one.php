<?php
require 'includes/db_connect.php';.

header('Content-Type: application/json');
function processMessage($update) {
    if($update["result"]["action"] == ""){
    	//Create File.
	//$fp = file_put_contents( 'request.log', $update["result"]["parameters"]["drive_app"] );
		//Return response.
		$msg="zoinks!";
		
		//authenticate
		if($update["result"]["metadata"]["intentName"]=="Login_password"){
			if 	($update["result"]["parameters"]["drive_app"]=="carwash" {
					// Define $myusername and $mypassword
					$myusername=sanatize($update["result"]["parameters"]["phone_number"],$con);
					$mypassword=sanatize($update["result"]["parameters"]["password"],$con);
					$sql="SELECT * FROM adult WHERE voice_num='".$myusername."' and password='".$mypassword."'";
					$result = mysqli_query($con,$sql);
					$count=mysqli_num_rows($result);
						if($count==1){
							$msg="You've been logged in.";
						} else {
							$msg="Sorry there was a problem with your authentication - please try again";
						}
			}
		}		
		
		
		//if($update["result"]["metadata"]["intentName"]=="drive.application"){
		//	if 	($update["result"]["parameters"]["drive_app"]=="carwash" or $update["result"]["parameters"]["drive_app"]=="elevator"){
		//		$msg="that sounds like a fine application.  do you need network communications";
		//	} else {
		//		$msg="maybe you should try something else";
		//	}
		//}




		
		
		
        sendMessage(array(
            "source" => $update["result"]["source"],
            //"speech" => $update["result"]["parameters"]["drive_app"],
            "speech" => $msg,
            //"displayText" => ".........TEXT HERE...........",
            "contextOut" => array()
        ));
    }
}
function sendMessage($parameters) {
	$req_dump = print_r( $parameters, true );
	$fp = file_put_contents( 'reques4.log', $req_dump );
	header('Content-Type: application/json');
    echo json_encode($parameters);
}

$update_response = file_get_contents("php://input");
$update = json_decode($update_response, true);
if (isset($update["result"]["action"])) {
    processMessage($update);
}
?>