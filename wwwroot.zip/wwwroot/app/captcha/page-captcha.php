<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body class="bg-white">

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->


    <!-- App Capsule -->
    <div id="appCapsule" class="pt-0">

					<?php session_start();


					if(isset($_POST['Submit'])){
						// code for check server side validation
						if(empty($_SESSION['captcha_code'] ) || strcasecmp($_SESSION['captcha_code'], $_POST['captcha_code']) != 0){  
							$msg="<span style='color:red'>The Validation code does not match!</span>";// Captcha verification is incorrect.		
						}else{// Captcha verification is Correct. Final Code Execute here!
							header('Location: /app/page-register.php');		
							//$msg="<span style='color:green'>The Validation code has been matched.</span>";		
						}
					}	
					?>
					<!doctype html>
					<html>
					<head>
					<meta charset="utf-8">
					<title>PHP Secure Professional Captcha.</title>
					<link href="./css/style.css" rel="stylesheet">
					<script type='text/javascript'>
					function refreshCaptcha(){
						var img = document.images['captchaimg'];
						img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
					}
					</script>
					</head>
					<body>
					<div id="frame0">
					  					  <p>Let us know you're a human!</a></p>
					</div>
					<br>

					<form action="" method="post" name="form1" id="form1" >
					  <table width="400" border="0" align="center" cellpadding="5" cellspacing="1" class="table">
					    <?php if(isset($msg)){?>
					    <tr>
					      <td colspan="2" align="center" valign="top"><?php echo $msg;?></td>
					    </tr>
					    <?php } ?>
					    <tr>
					      <td align="right" valign="top"> Validation code:</td>
					      <td><img src="captcha.php?rand=<?php echo rand();?>" id='captchaimg'><br>
					        <label for='message'>Enter the code above here :</label>
					        <br>
					        <input id="captcha_code" name="captcha_code" type="text">
					        <br>
					        Can't read the image? <a href='javascript: refreshCaptcha();'>Refresh</a></td>
					    </tr>
					    <tr>
					      <td>&nbsp;</td>
					      <td><input name="Submit" type="submit" onclick="return validate();" value="Submit" class="button1"></td>
					    </tr>
					  </table>
					</form>
					</body>
					</html>


    </div>
    <!-- * App Capsule -->



    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>

</body>

</html>