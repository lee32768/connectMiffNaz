<?php
require 'db_connect.php';


	// Define $myusername and $mypassword
	$myusername=sanatize($_POST['user'],$con);
	$mypassword=sanatize($_POST['pass'],$con);

	//check for phone number
	preg_match_all("/[0-9]/",$myusername,$digits);
	$phonenumber = implode("",$digits[0]);
	//echo $myusername;
	//echo "<br>";
	//echo "digit string ". $phonenumber;
	//echo "<br>";
	//echo "number of digits returned ".strlen($phonenumber);
	//echo "<br>";
	//print_r($digits);
	
	
	if (strlen($phonenumber)==10){
		$sql="SELECT * FROM adult WHERE sms_num='".$phonenumber."' and password='".$mypassword."'";	
	//echo $sql;	
		}else {
		$sql="SELECT * FROM adult WHERE email='".$myusername."' and password='".$mypassword."'";	
	}		
	$result = mysqli_query($con,$sql);
	$count=mysqli_num_rows($result);


	// If result matched $myusername and $mypassword, table row must be 1 row

	if($count==1){
		$row = mysqli_fetch_assoc($result);
		//define session variables for user
		session_start();
		//set session Length
		$cookieLifetime = 90 * 24 * 60 * 60; // in seconds
		setcookie(session_name(),session_id(),time()+$cookieLifetime);
		
		$_SESSION["authorized"] = 'yes';
		$_SESSION["permissions"] = $row['permission_level'];
		$_SESSION["notifications"] = $row['sys_notification'];
		$_SESSION["name"] = $row['name'];
		$_SESSION["surname"] = $row['surname'];
		$_SESSION["fullname"] = $row['name']." ".$row['surname'];
		$_SESSION["email"] = $row['email'];
		$_SESSION["passwordattempt"] = 'no';
		$_SESSION["adult_id"] = $row['adult_id'];
		unset($_SESSION['youth_id']);
		$_SESSION["message1"] = '';
		$_SESSION["message2"] = '';
		
		if(!isset($_COOKIE['user'])) {
			//no cookie found on the local browser
			$sql5="select * from cookies where adult_id='".$_SESSION["adult_id"]."'";
			$result5 = mysqli_query($con,$sql5);
			$count5=mysqli_num_rows($result5);
			
		if($count5==1){
			//cookie found in database but not locally - update latest login
			$dateform = date("Y-m-d H:i:s");	
			$row5 = mysqli_fetch_assoc($result5);
			$sql7="update cookies set last_login='".$dateform."' where cookie='".$row5['cookie']."'";
			mysqli_query($con,$sql7);			
			//set the local cookie
			setcookie('user', $row5['cookie'], time() + (86400 * 90), "/"); // 86400 = 1 day
			header("location:index.php");
			
			} else {
			//no cookie found in the database - create one and create local cookie
			
			$dateform = date("Y-m-d H:i:s");
			$str_cookie=$_SESSION["adult_id"]."-".md5(rand());
			$sql6="insert into cookies (adult_id,cookie,issue_date,last_login ) values ('".$_SESSION["adult_id"]."','".$str_cookie."','".$dateform."','".$dateform."')";
			//echo $sql6;
			$result6=mysqli_query($con,$sql6);	
			//set the local cookie
			setcookie('user', $str_cookie, time() + (86400 * 90), "/"); // 86400 = 1 day
			header("location:index.php");
			}
			
			
  			
		} else {
			//local cookie found - update last login
			$dateform = date("Y-m-d H:i:s");
			$sql8="update cookies set last_login='".$dateform."' where cookie='".$_COOKIE['user']."'";
			//echo $sql8;
			mysqli_query($con,$sql8);
			header("location:index.php");
  			
		}
		
		//header("location:index.php");
		
		} else {
			//now check for youth account
			if (strlen($phonenumber)==10){
				$sql2="SELECT * FROM youth WHERE sms_num='".$phonenumber."' and password='".$mypassword."'";	
				//echo $sql;	
				}else {
				$sql2="SELECT * FROM youth WHERE email='".$myusername."' and password='".$mypassword."'";	
				}
			$result2 = mysqli_query($con,$sql2);
			$count2=mysqli_num_rows($result2);
				if($count2==1){
					$row2 = mysqli_fetch_assoc($result2);
					//define session variables for user
					session_start();
					//set session Length
					$cookieLifetime = 90 * 24 * 60 * 60; // in seconds
					setcookie(session_name(),session_id(),time()+$cookieLifetime);
					
					$_SESSION["authorized"] = 'yes';
					//$_SESSION["permissions"] = $row2['permission_level'];
					//$_SESSION["notifications"] = $row2['sys_notification'];
					$_SESSION["name"] = $row2['name'];
					$_SESSION["surname"] = $row2['surname'];
					$_SESSION["fullname"] = $row2['name']." ".$row2['surname'];
					//$_SESSION["email"] = $row2['email'];
					$_SESSION["passwordattempt"] = 'no';
					$_SESSION["youth_id"] = $row2['youth_id'];
					unset($_SESSION['adult_id']); 
					$_SESSION["message1"] = '';
					$_SESSION["message2"] = '';
					header("location:index.php");
					
					} else {
						session_start();
						$_SESSION["authorized"] = 'no';
						$_SESSION["passwordattempt"] = 'yes';
						$_SESSION["message1"] = 'You have entered an incorrect user name or password';
						$_SESSION["message2"] = 'Please try again or request your password to be emailed to you';
						header("location:index.php");
						//echo "failure";
						
					}	
		}














?>
