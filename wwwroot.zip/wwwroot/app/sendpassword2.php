<?php
require 'db_connect.php';
require 'mail_functions.php';
require 'que_sms.php';


	// Define $myusername and $mypassword
	$myusername=sanatize($_POST['user'],$con);
	
	//check for phone number
	preg_match_all("/[0-9]/",$myusername,$digits);
	$phonenumber = implode("",$digits[0]);

if (strlen($phonenumber)==10){
	$sql="SELECT * FROM adult WHERE sms_num='".$phonenumber."'";
	$usertype = "number";	
	//echo $sql;	
		}else {
	$sql="SELECT * FROM adult WHERE email='".$myusername."'";	
	$usertype = "email";
	}

	//echo $phonenumber."<br>";
	//echo $usertype."<br>";
	//echo $sql."<br>";
	$result = mysqli_query($con,$sql);

	// Mysql_num_row is counting table row
	$count=mysqli_num_rows($result);


	// If result matched $myusername and $mypassword, table row must be 1 row

	if($count==1){
		$row = mysqli_fetch_assoc($result);

		
		$body = "Your Password is: ".$row['password']; 
		$full = $row['name']." ".$row['surname'];
		$address = $row['email'];
		$subject = "MiffNaz Portal Password Request";
		
		if ($usertype=="email"){
			instant_mail($full,$address,$body,$subject);
			//echo "email sent<br>";		
		}
		if ($usertype=="number"){
			$dateform = date_format(date_create(date("Y-m-d H:i:s")),"l F jS - h:i a");
			que_single_sms('system',$dateform,'15709660852',$phonenumber,$body,'password request',$con);
			//echo "sms sent<br>";
		}
		que_sys_mail('1',$full,$con);
		
		header("location:index.php");
		} else {
		echo "email not found or duplicate records returned";
	}

?>












