<?php
require 'db_connect.php';
session_start();

	// Define $myusername and $mypassword
	$child_id=sanatize($_POST['child_id'],$con);
	$act_id=sanatize($_POST['act_id'],$con);

	
	

	
	

$ssql = "delete from soccer where act_id='".$act_id."' and child_id='".$child_id."'";

$result = mysqli_query($con,$ssql);
//echo $ssql;
//echo "<br>";
header("location:kidsmain.php");

?>