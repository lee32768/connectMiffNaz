﻿<?php
if(!isset($_SESSION)) {
     session_start();
}
if($_SESSION["authorized"]<>'yes') {
     header("location:main_login.html");
}
require 'db_connect.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="../assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/img/icon/192x192.png">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="../index.php" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">KidzKonnect</div>
        <div class="right"></div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="full-height">


        <div class="section full mt-2">
            <div class="section-title">Register you Children for Events Here!</div>
            <div class="wide-block pt-2 pb-2">
				<h5>Create New Children under "my info"</h5>
            </div>
            <div class="wide-block pt-2 pb-2">
				<?php
						$sSql="SELECT * FROM `activity_list` WHERE curdate() between `reg_start` and `reg_end` order by `act_start` ";
						$result1 = mysqli_query($con,$sSql);
						while($row1 = mysqli_fetch_array($result1)) {
							$table=$row1['act_table'];
							$inturl=$row1['act_url_app'];
							$act_id=$row1['act_id'];
							echo"<div class=\"row\">";
			                echo"<div class=\"col-lg-4 col-md-4\">";
							//echo"<h5>Panel Sample</h5>";
			                echo"<div class=\"panel panel-primary\">";
							echo"<div class=\"panel-heading\">";
							echo $row1['act_name'];
			                echo"</div>";
			                echo"<div class=\"panel-body\">";
			                echo"<p>".$row1['act_desc']."</p>";
			                
			                echo"<p>Start date: ".$row1['act_start']."<br>";
			                echo"End date: ".$row1['act_end']."<br>";
			                echo"Registration Ends: ".$row1['reg_end']."</p>";
			                
			            
							echo"</div>";
							echo"<div class=\"panel-footer\" >";
							echo"<p>Actions</p>";
							
							
							$sSql10="select * from child where adult_id='".$_SESSION['adult_id']."'";
							
							$result10 = mysqli_query($con,$sSql10);
							while($row10 = mysqli_fetch_array($result10)) {
								$sSql11="SELECT * FROM ".$table." WHERE child_id='".$row10['child_id']."' and act_id='".$act_id."'";
								$result11 = mysqli_query($con,$sSql11);
								$count=mysqli_num_rows($result11);
								if ($count>0){
									$row11 = mysqli_fetch_array($result11,MYSQLI_ASSOC);
									//unregister for district quiz
									if ($row1['act_type']=='districtquizzing'){	
										echo"<form action=\"kids_unreg_districtquiz_script.php\" method=\"post\">";
										}
									//unregister for vbs
									if ($row1['act_type']=='vbs'){	
										echo"<form action=\"kids_unreg_vbs_script.php\" method=\"post\">";
										}
									//unregister for caravan
									if ($row1['act_type']=='caravan'){	
										echo"<form action=\"kids_unreg_caravan_script.php\" method=\"post\">";
										}
									//unregister for soccer
									if ($row1['act_type']=='soccer'){	
										echo"<form action=\"kids_unreg_soccer_script.php\" method=\"post\">";
										}
									echo"<input type=\"hidden\" name=\"act_id\" value=\"".$act_id."\">";
									echo"<input type=\"hidden\" name=\"child_id\" value=\"".$row10['child_id']."\">";
	  								echo"<button type=\"submit\" name=\"your_name\" value=\"your_value\" class=\"btn btn-danger\">Unregister ".$row10['name']." ".$row10['surname']."</button>";
									echo"</form>";
									echo"<br>";	
								} else {
									echo"<form action=\"".$inturl."\" method=\"post\">";
									echo"<input type=\"hidden\" name=\"act_id\" value=\"".$act_id."\">";
									echo"<input type=\"hidden\" name=\"child_id\" value=\"".$row10['child_id']."\">";
	  								echo"<button type=\"submit\" name=\"your_name\" value=\"your_value\" class=\"btn btn-primary\">Register ".$row10['name']." ".$row10['surname']."</button>";
									echo"</form>";
									echo"<br>";
								}													
							}
							//show lunch and staff registration if this is a district quizzing event
							if ($row1['act_type']=='districtquizzing'){					
									echo"<form action=\"kids_reg_districtquiz_lunch.php\" method=\"post\">";
									echo"<input type=\"hidden\" name=\"act_id\" value=\"".$act_id."\">";
									echo"<input type=\"hidden\" name=\"adult_id\" value=\"".$_SESSION["adult_id"]."\">";
	  								echo"<button type=\"submit\" name=\"your_name\" value=\"your_value\" class=\"btn btn-default\">Select Lunches</button>";
									echo"</form>";
									echo"<br>";	
									
									echo"<form action=\"kids_reg_districtquiz_staff.php\" method=\"post\">";
									echo"<input type=\"hidden\" name=\"act_id\" value=\"".$act_id."\">";
									echo"<input type=\"hidden\" name=\"adult_id\" value=\"".$_SESSION["adult_id"]."\">";
	  								echo"<button type=\"submit\" name=\"your_name\" value=\"your_value\" class=\"btn btn-default\">Register Staff</button>";
									echo"</form>";
									echo"<br>";	
							}


							

							
							
							
							
							
			                echo"</div>";
			                echo"</div>";
			                echo"</div>";	
			                echo"</div>";
						}

					?>
				
				
				
            </div>
        </div>



    </div>
    <!-- * App Capsule -->



    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="../assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="../assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="../assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="../assets/js/base.js"></script>

</body>

</html>