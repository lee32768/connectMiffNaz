<?php
if(!isset($_SESSION)) {
     session_start();
}
if($_SESSION["authorized"]<>TRUE) {
     header("location:/app/index.php");
}
require 'db_connect.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="../assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/img/icon/192x192.png">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="../index.php" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">KidzKonnect</div>
        <div class="right"></div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="full-height">


        <div class="section full mt-2">
            <div class="section-title">Soccer</div>
            <div class="wide-block pt-2 pb-2">
				<h5></h5>
            </div>
<div class="wide-block pt-2 pb-2">
			                  <!-- /. ROW  --> 
                  <?php
                  	$sSql="SELECT name FROM child WHERE child_id='".$_POST['child_id']."'";
					$result = mysqli_query($con,$sSql);
					$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
                  ?>
					<div class="row">
                    <div class="col-lg-4 col-md-4">
                        
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Register <?php echo $row['name']; ?>
                            </div>
                            <div class="panel-body">
                                <FORM ACTION="kids_reg_soccer_script.php" METHOD="POST">
					<div class="form-group boxed">
                        <div class="input-wrapper">
                        <div class="mb-05">Jersey Size:</div>
                           <!--< label class="form-label" for="tshirt">Jersey Size:</label>-->
                            <select class="form-control form-select" id="tshirt" name="tshirt">
                                <!--
                                <option value="0">Select a city</option>
                                <option value="1">New York City</option>
                                <option value="2">Austin</option>
                                <option value="3">Colorado</option>
                                -->
                                <option>Child X-Small</option>
								<option>Child Small</option> 
								<option>Child Medium</option> 
								<option>Child Large</option>
								<option>Child X-Large</option>
								<option>Adult Small</option>
								<option>Adult Medium</option>
								<option>Adult Large</option>
								<option>Adult X-Large</option>										  
								<option>Adult XX-Large</option>
                            </select>
                        </div>
                    </div>
								<br>
								
					<div class="mb-05">Skill Level - 1(novice)...5(pro)</div>								
					<div class="col-6 text-center mb-2">
                        <!-- stepper success -->
                        <div class="stepper stepper-dark">
                            <a href="#" class="stepper-button stepper-down">-</a>
                            <input type="number" class="form-control" value="1" id="skill" name="skill" min="1" max="5" disabled />
                            <a href="#" class="stepper-button stepper-up">+</a>
                        </div>
                        <!-- * stepper success -->
                    </div>
                    
                    <br>
					<br>

									

									<input type="hidden" name="child_id" value="<?php echo $_POST['child_id'] ?>">
									<input type="hidden" name="act_id" value="<?php echo $_POST['act_id'] ?>">
									
									
									<div class="col-lg-4 col-md-4">
				                    <div class="form-group">
				                    <br>
				                    <center>
				                        <input type="submit" value="Register" class="btn btn-primary"></a>
				                    </center>
				                    </div>
							        </div>
									
									
									
									
                                </FORM>
                            </div>
                            
                        </div>
                    </div>
    


                  		
                  
                
             <!-- /. PAGE INNER  -->
            </div>	
				
				
				
				
				
</div>
        </div>



    </div>
    <!-- * App Capsule -->



    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="../assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="../assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="../assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="../assets/js/base.js"></script>

</body>

</html>