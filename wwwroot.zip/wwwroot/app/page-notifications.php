<?php
require 'db_connect.php';
?>

<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body>

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="index.php" class="headerButton">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">Notifications</div>
        <!--<div class="right">
            <a href="#" class="headerButton">
                <ion-icon name="videocam-outline"></ion-icon>
            </a>
            <a href="#" class="headerButton">
                <ion-icon name="call-outline"></ion-icon>
                <span class="badge badge-danger">1</span>
            </a>
        </div>-->
        
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">



      


            
        <?php   
        	session_start(); 
           //$sql="select sub.* from (SELECT * FROM db533946139.phonetree_campaigns where groupid in (select group_id from db533946139.phonetree where adult_id=".$_SESSION["adult_id"].") order by created desc limit 10) as sub order by created asc";
           if (isset($_SESSION['adult_id'])) {
           	 $sql="select sub.* from (SELECT phonetree_campaigns.*,adult.name,adult.surname,phonetree_groups.group_name FROM phonetree_campaigns inner join adult on phonetree_campaigns.adult_id=adult.adult_id inner join phonetree_groups on phonetree_groups.group_id=phonetree_campaigns.groupid where groupid in (select group_id from phonetree where adult_id=".$_SESSION["adult_id"].") order by created desc limit 10) as sub order by created asc";
           	}
           if (isset($_SESSION['youth_id'])) {
			 $sql="select sub.* from (SELECT phonetree_campaigns.*,adult.name,adult.surname,phonetree_groups.group_name FROM phonetree_campaigns inner join adult on phonetree_campaigns.adult_id=adult.adult_id inner join phonetree_groups on phonetree_groups.group_id=phonetree_campaigns.groupid where groupid in (select group_id from phonetree where youth_id=".$_SESSION["youth_id"].") order by created desc limit 10) as sub order by created asc";
           	 }           	
           //echo $sql;
				
           $result = mysqli_query($con,$sql);
           while($row = mysqli_fetch_array($result)) {
           	
             	echo "<div class=\"message-divider\">";
           		echo $row['group_name'];
        		echo "</div>";
           	
           	
           		echo "<div class=\"message-item\"> \n";
           		$avatar_path="assets/img/avatars/avatar".$row["adult_id"].".jpg";
           		if (file_exists($avatar_path)){
           		echo "<img src=\"".$avatar_path."\" alt=\"avatar\" class=\"avatar\"> \n";					
				} else {
				echo "<img src=\"assets/img/avatars/avatar_blank.jpg\" alt=\"avatar\" class=\"avatar\"> \n";	
				}
           		echo "<div class=\"content\"> \n";
           		echo "<div class=\"title\">".$row['name']." ".$row['surname']."</div> \n";
           		echo "<div class=\"bubble\">";
           		echo $row['sMsg'];
           		echo "</div> \n";
           		//$strtime=$row['created'];
           		//$date_date=date_format($strtime,"D,M,jS h:iA");
				echo "<div class=\"footer\">".$row['created']."</div> \n";
           		echo "</div> \n";
           		echo "</div> \n"; 	
           			
			} 
        ?>
        	
            
           
                
                
                    
                
                
            
        


        
        
        
        
        
        
        
        
    </div>
    <!-- * App Capsule -->

    <!-- Add Action Sheet -->
    <div class="offcanvas offcanvas-bottom action-sheet inset" tabindex="-1" id="actionSheetAdd">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Share</h5>
        </div>
        <div class="offcanvas-body">
            <ul class="action-button-list">
                <li>
                    <a href="#" class="btn btn-list" data-bs-dismiss="offcanvas">
                        <span>
                            <ion-icon name="camera-outline"></ion-icon>
                            Take a photo
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#" class="btn btn-list" data-bs-dismiss="offcanvas">
                        <span>
                            <ion-icon name="videocam-outline"></ion-icon>
                            Video
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#" class="btn btn-list" data-bs-dismiss="offcanvas">
                        <span>
                            <ion-icon name="image-outline"></ion-icon>
                            Upload from Gallery
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#" class="btn btn-list" data-bs-dismiss="offcanvas">
                        <span>
                            <ion-icon name="document-outline"></ion-icon>
                            Documents
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#" class="btn btn-list" data-bs-dismiss="offcanvas">
                        <span>
                            <ion-icon name="musical-notes-outline"></ion-icon>
                            Sound file
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- * Add Action Sheet -->



    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>
   
    <!-- scroll to bottom --> 
    <script>
    	window.scrollTo({ left: 0, top: document.body.scrollHeight, behavior: "smooth" });
    </script>
    

</body>

</html>