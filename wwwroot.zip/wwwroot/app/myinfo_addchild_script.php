<?php
require 'db_connect.php';
require 'mail_functions.php';
//session_start();

	// Define $myusername and $mypassword
	$name=sanatize($_POST['name'],$con);
	$surname=sanatize($_POST['surname'],$con);
	$DOB=sanatize($_POST['DOB'],$con);
	$allergy=sanatize($_POST['allergy'],$con);
	$notes=sanatize($_POST['notes'],$con);
	
	

	
	

$ssql = "insert into child (name, surname, adult_id, DOB, allergy, notes) values ('".$name."','".$surname."','".$_SESSION["adult_id"]."','".$DOB."','".$allergy."','".$notes."')";

$result = mysqli_query($con,$ssql);

		$body="You have added ".$name." ".$surname." to your list of children";
		que_mail('',$_SESSION["fullname"],$_SESSION['email'],'','New Child Added',$body,$_SESSION['fullname'],'',$con);

		
		$body=$_SESSION["fullname"]." has created ".$name." ".$surname." in the system";
		que_sys_mail('4',$body,$con);

//echo $ssql;
//echo "<br>";
header("location:myinfo.php");

?>