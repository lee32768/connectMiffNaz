<?php
require 'db_connect.php';


	$sql="SELECT * FROM cookies WHERE cookie='".$_COOKIE['user']."'";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_assoc($result);
if (is_null($row['youth_id'])){
	echo"adult found";
	//pull data from adult
	$sql2="SELECT * FROM adult WHERE adult_id='".$row['adult_id']."'";
	$result2 = mysqli_query($con,$sql2);
	$row2 = mysqli_fetch_assoc($result2);	
	
	session_start();
		//set session Length
		$cookieLifetime = 90 * 24 * 60 * 60; // in seconds
		setcookie(session_name(),session_id(),time()+$cookieLifetime);
		
		$_SESSION["authorized"] = 'yes';
		$_SESSION["permissions"] = $row2['permission_level'];
		$_SESSION["notifications"] = $row2['sys_notification'];
		$_SESSION["name"] = $row2['name'];
		$_SESSION["surname"] = $row2['surname'];
		$_SESSION["fullname"] = $row2['name']." ".$row2['surname'];
		$_SESSION["email"] = $row2['email'];
		$_SESSION["passwordattempt"] = 'no';
		$_SESSION["adult_id"] = $row2['adult_id'];
		unset($_SESSION['youth_id']);
		$_SESSION["message1"] = '';
		$_SESSION["message2"] = '';
		
		$dateform = date("Y-m-d H:i:s");
		$sql8="update cookies set last_login='".$dateform."' where cookie='".$_COOKIE['user']."'";
		mysqli_query($con,$sql8);
		
		header("location:index.php");	
	
} else {
	echo"youth found";
	//pull data from youth
	$sql3="SELECT * FROM youth WHERE youth_id='".$row['youth_id']."'";
	$result3 = mysqli_query($con,$sql3);
	$row3 = mysqli_fetch_assoc($result3);
	
		session_start();
		//set session Length
		$cookieLifetime = 90 * 24 * 60 * 60; // in seconds
		setcookie(session_name(),session_id(),time()+$cookieLifetime);
		
		$_SESSION["authorized"] = 'yes';
		$_SESSION["permissions"] = $row3['permission_level'];
		$_SESSION["notifications"] = $row3['sys_notification'];
		$_SESSION["name"] = $row3['name'];
		$_SESSION["surname"] = $row3['surname'];
		$_SESSION["fullname"] = $row3['name']." ".$row3['surname'];
		$_SESSION["email"] = $row3['email'];
		$_SESSION["passwordattempt"] = 'no';
		$_SESSION["adult_id"] = $row3['adult_id'];
		unset($_SESSION['youth_id']);
		$_SESSION["message1"] = '';
		$_SESSION["message2"] = '';
		
		$dateform = date("Y-m-d H:i:s");
		$sql9="update cookies set last_login='".$dateform."' where cookie='".$_COOKIE['user']."'";
		mysqli_query($con,$sql9);
		
		header("location:index.php");
	
	
	
	
}















?>
