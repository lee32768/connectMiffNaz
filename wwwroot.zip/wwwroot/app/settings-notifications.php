<!doctype html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
    
    
<script type="text/javascript">
        (function(d, t) {
                var g = d.createElement(t),
                s = d.getElementsByTagName(t)[0];
                g.src = "https://cdn.pushalert.co/integrate_c7deb8a5d53015e10f0713d87debe7b8.js";
                s.parentNode.insertBefore(g, s);
        }(document, "script"));
        
     
    (pushalertbyiw = window.pushalertbyiw || []).push(['onReady', onPAReady]);
    
	function onPAReady() {
        console.log(PushAlertCo.subs_id); //if empty then user is not subscribed
    }


    function onUNSUB() {
        PushAlertCo.unsubscribe();
    }
    
    function onTRIGGER() {
        PushAlertCo.triggerMe(true); //You can call this method to request the opt-in manually
    }

</script>
</head>

<body>

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="index.php" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">Settings</div>
        <div class="right"></div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule" class="full-height">


        <div class="section full mt-2">
            <div class="section-title">Notifications</div>
            <div class="wide-block pt-2 pb-2">
            	Push Notifications (Android Only)
            	<a href="register_subscriberID.php">
                	<button type="button" class="btn btn-warning me-1 mb-1">Submit</button>
                </a>
                
                <button type="button" onclick = "onUNSUB();" class="btn btn-warning me-1 mb-1">Unsubscribe</button>
                <button type="button" onclick = "onTRIGGER();" class="btn btn-warning me-1 mb-1">Subscribe</button>
            </div>

        </div>



    </div>
    <!-- * App Capsule -->


    <!-- * App Bottom Menu -->


    <!-- * App Sidebar -->

    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>

</body>

</html>