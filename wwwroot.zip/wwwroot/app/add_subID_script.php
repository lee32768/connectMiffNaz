<?php
if(!isset($_SESSION)) {
     session_start();
}
if($_SESSION["authorized"]<>'yes') {
     header("location:index.php");
}
require 'db_connect.php';

$adult_id=$_GET['adult_id'];
$subID=$_GET['subs_id'];

echo $adult_id;
echo "<br>";
echo $subID;
echo "<br>";


		$ssql = "update adult set pushID='".$subID."' where adult_id='".$adult_id."'";	
		echo $ssql;
		$result = mysqli_query($con,$ssql);





//echo "<br>";
//header("location:index.php");

?>