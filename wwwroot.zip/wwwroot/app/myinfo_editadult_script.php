<?php
require 'db_connect.php';
session_start();

	// Define $myusername and $mypassword
	$name=sanatize($_POST['name'],$con);
	$surname=sanatize($_POST['surname'],$con);
	$street=sanatize($_POST['street'],$con);
	$town=sanatize($_POST['town'],$con);
	$state=sanatize($_POST['state'],$con);
	$zip=sanatize($_POST['zip'],$con);
	$phone=sanatize($_POST['phone'],$con);
	$email=sanatize($_POST['email'],$con);
	$church=sanatize($_POST['church'],$con);
	

	
	

$ssql = "update adult set name='".$name."', surname='".$surname."', street='".$street."', town='".$town."', state='".$state."', zip='".$zip."', phone='".$phone."', email='".$email."', church_id='".$church."' where adult_id='".$_SESSION["adult_id"]."'";

$result = mysqli_query($con,$ssql);
//echo $ssql;
//echo "<br>";
header("location:myinfo.php");

?>