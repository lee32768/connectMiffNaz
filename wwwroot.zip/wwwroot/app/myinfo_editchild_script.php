<?php
require 'db_connect.php';
session_start();

	// Define $myusername and $mypassword
	$name=sanatize($_POST['name'],$con);
	$surname=sanatize($_POST['surname'],$con);
	$DOB=sanatize($_POST['DOB'],$con);
	$allergy=sanatize($_POST['allergy'],$con);
	$notes=sanatize($_POST['notes'],$con);
	$child_id=sanatize($_POST['child_id'],$con);
	

	
	

$ssql = "update child set name='".$_POST["name"]."', surname='".$_POST["surname"]."', adult_id='".$_SESSION["adult_id"]."', DOB='".$_POST["DOB"]."', allergy='".$_POST["allergy"]."', notes='".$_POST["notes"]."' where child_id='".$child_id."'";

$result = mysqli_query($con,$ssql);
//echo $ssql;
//echo "<br>";
header("location:myinfo.php");

?>