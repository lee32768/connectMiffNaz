<?php
require 'db_connect.php';
require 'mail_functions.php';
session_start();
	
	$duplicate="no";
	$name=sanatize($_POST['name'],$con);
	$surname=sanatize($_POST['surname'],$con);
	$email=sanatize($_POST['email'],$con);
	$pass=sanatize($_POST['password'],$con);

	//check for duplicate email addresses
	$sql="SELECT * FROM adult WHERE email='".$email."'";
	$result = mysqli_query($con,$sql);
	$count=mysqli_num_rows($result);
	if($count>=1){
		$duplicate="yes";
		}

	//check for duplicate names
	$sql="SELECT * FROM adult WHERE name='".$name."' and surname='".$surname."'";
	$result = mysqli_query($con,$sql);
	$count=mysqli_num_rows($result);
	if($count>=1){
		$duplicate="yes";
		}
	
		
	if($duplicate=="yes"){
		$_SESSION['message1']="You've used an email address or name that already exists";		
		$_SESSION['message2']="Please login or request your password be sent to you";
		header("location:page-register.php");		
	} else {
		//default permission level loaded 130 - that's myinfo and kidskonnect
		$sql="insert into adult (name, surname, email, password, permission_level) values ('".$name."','".$surname."','".$email."','".$pass."','130')";
		$result = mysqli_query($con,$sql);
		$_SESSION['message1']="Welcome to the MiffNaz Portal!";		
		$_SESSION['message2']="Please click 'MY INFO' to complete your profile";
		$sql="SELECT * FROM adult WHERE email='".$email."' and password='".$pass."'";
		$result = mysqli_query($con,$sql);
		$row = mysqli_fetch_assoc($result);
		$_SESSION["authorized"] = 'yes';
		$_SESSION["permissions"] = $row['permission_level'];
		$_SESSION["notifications"] = $row['sys_notification'];
		$_SESSION["name"] = $row['name'];
		$_SESSION["surname"] = $row['surname'];
		$_SESSION["fullname"] = $row['name']." ".$row['surname'];
		$_SESSION["email"] = $row['email'];
		$_SESSION["passwordattempt"] = 'no';
		$_SESSION["adult_id"] = $row['adult_id'];
		instant_mail($_SESSION["fullname"],$_SESSION["email"],'http://connect.miffnaz.org','Welcome to the MiffNaz Portal');
		que_sys_mail('3',$_SESSION["fullname"],$con);
		header("location:index.php");
	}














?>
