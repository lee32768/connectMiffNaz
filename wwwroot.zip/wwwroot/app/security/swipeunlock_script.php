<?php
require 'db_connect.php';
require 'mail_functions.php';
//session_start();

	// Define $myusername and $mypassword
	$door=sanatize($_GET['door_num'],$con);

	
    $sql="SELECT * from security_doors where door_num='".$door."'";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);

	$ch = curl_init($row['swipe_url']);
	curl_exec($ch);
	curl_close($ch);

//echo $sql;
//echo "<br>";
//echo $ch;
header("location:swipeunlock.php");

?>