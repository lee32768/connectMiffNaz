<?php
if(!isset($_SESSION)) {
     session_start();
}
if($_SESSION["authorized"]<>'yes') {
     header("location:main_login.html");
}
require 'db_connect.php';
?>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="theme-color" content="#000000">
    <title>MiffNaz Mobile</title>
    <meta name="description" content="MiffNaz Mobile">
    <meta name="keywords" content="bootstrap 5, mobile template, cordova, phonegap, mobile, html" />
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="manifest" href="__manifest.json">
</head>

<body class="bg-white">

    <!-- loader -->
    <div id="loader">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- * loader -->

    <!-- App Header -->
    <div class="appHeader no-border transparent">
        <div class="left">
        </div>
        <div class="pageTitle">
            <!--<img src="assets/img/logo.png" alt="logo" class="logo">-->
        </div>
        <div class="right">
            <a href="index.php" class="headerButton text-secondary">
                Back
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">


        <!-- carousel slider -->
        <div class="carousel-slider splide">
            <div class="splide__track">
                <ul class="splide__list">
                    <li class="splide__slide p-2">
                        <!-- <img src="assets/img/sample/photo/vector1.png" alt="alt" class="imaged w-100 square mb-4"> -->
                        <h2>About Me</h2>
                        <p>
                                <?php
									$sSql="SELECT * FROM adult WHERE adult_id='".$_SESSION["adult_id"]."'";
									$result = mysqli_query($con,$sSql);
									$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
									$sSql1="SELECT name FROM churches WHERE id='".$row['church_id']."'";
									$result1 = mysqli_query($con,$sSql1);
									$row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);
								?>
									<FORM ACTION="myinfo_editadult_script.php" METHOD="POST">
									
																	<!-- First Name  -->
									<div class="row">
                    					<div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>First Name:</label>
                            				<input class="form-control" name="name" value="<?PHP echo $row['name'];  ?>"/>
                            				<p class="help-block"></p>
                            			</div>
                    					</div>                    				
                					
																	<!-- Last Name  -->
									
                    					<div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Last Name:</label>
                            				<input class="form-control" name="surname" value="<?PHP echo $row['surname'];  ?>"/>
                            			</div>
                    					</div>
                    				</div>									                                    
                                   
                                   									<!-- Street  -->
									<div class="row">
                    				    <div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Street:</label>
                            				<input class="form-control" name="street" value="<?PHP echo $row['street'];  ?>"/>
                            			</div>
                    					</div>                    				
                						
                					
                													<!-- town  -->
									
                    			        <div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Town:</label>
                            				<input class="form-control" name="town" value="<?PHP echo $row['town'];  ?>"/>
                            			</div>
                    					</div>
                    				</div>	


                													<!-- state  -->
									<div class="row">
                    			        <div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>State:</label>
                            				<input class="form-control" name="state" value="<?PHP echo $row['state'];  ?>"/>
                            			</div>
                    					</div>
                    				

                                   
                                   									<!-- zip  -->
									
                    					<div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Zip Code:</label>
                            				<input class="form-control" name="zip" value="<?PHP echo $row['zip'];  ?>"/>
                            			</div>
                    					</div>
                    				</div>	
                                   
                                   									<!-- phone  -->
									<div class="row">
                    					<div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Phone:</label>
                            				<input class="form-control" name="phone" value="<?PHP echo $row['phone'];  ?>"/>
                            			</div>
                    					</div>
                    					
                                   
                                   									<!-- email  -->
									
                    					<div class="col-lg-6 col-md-4">
                        				<div class="form-group">
                            				<label>Email:</label>
                            				<input class="form-control" name="email" value="<?PHP echo $row['email'];  ?>"/>
                            			</div>
                    					</div>
                    				</div>	
                					
                														<!-- Home Church  -->
									<div class="row">
                    					<div class="col-lg-8 col-md-4">
										<div class="form-group">
										  <label for="sel1">Home Church:</label>
										  <select class="form-control" id="church" name="church">
										  <?PHP
										  $sSql2="SELECT * FROM churches";
										  $result2 = mysqli_query($con,$sSql2);
											while ($row2=mysqli_fetch_assoc($result2)){
										  		echo "<option"; 
										  		if ($row['church_id']==$row2['id']){
												echo " selected=\"selected\" ";
												}
										  		echo " value=\"".$row2['id']."\">".$row2['name'].", ".$row2['town']." ".$row2['state']."</option>";
										  	}	  		
										  ?>
										  </select>
										</div>
                    					</div>
                    				</div>	
                    				<br>
                    			 <div class="row">
				                    <div class="col-lg-4 col-md-4">
				                        <div class="form-group">
				                            <center>
				                                <input type="submit" value="Update" class="btn btn-primary"></a>
				                            </center>
				                        </div>
				                    </div>
				                </div>
                                
                           	
                                   </FORM>                        
                        </p>
                    </li> 

                    <li class="splide__slide p-2">                        
                        <h2>My Children</h2>
                        <h5>(birth...6th grade)</h5>
                        <br>
                        <br>
                        <p>
                        
                        <div class="section full mt-2">
			            <div class="section-title"></div>

			            <div class="accordion" id="accordionExample1">
			        	<?php
				        $x=1;
					    $sSql4="SELECT * FROM child WHERE adult_id='".$_SESSION["adult_id"]."' and active='1'";
						$result4 = mysqli_query($con,$sSql4);
						while($row4 = mysqli_fetch_array($result4)) {
			            	echo"<FORM ACTION=\"myinfo_editchild_script.php\" METHOD=\"POST\"> \n";
			                echo"<div class=\"accordion-item\"> \n";
			                echo"<h2 class=\"accordion-header\"> \n";
			                echo"       <button class=\"accordion-button collapsed\" type=\"button\" data-bs-toggle=\"collapse\" \n";
			                echo"            data-bs-target=\"#accordion".$x."\">  ".$row4['name']." \n";
			                echo"        </button> \n";
			                echo"    </h2> \n";
			                echo"    <div id=\"accordion".$x."\" class=\"accordion-collapse collapse\" data-bs-parent=\"#accordionExample1\"> \n";
			                echo"        <div class=\"accordion-body\"> \n";			                
													echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>First Name:</label>";
                            						echo"<input class=\"form-control\" name=\"name\" value=\"".$row4["name"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								//echo"</div>"; 

													//echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Last Name:</label>";
                            						echo"<input class=\"form-control\" name=\"surname\" value=\"".$row4["surname"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>"; 

 	                   								
 	                   								echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Date of Birth:</label>";
                            						echo"<input class=\"form-control\" type=\"date\" name=\"DOB\" value=\"".$row4["DOB"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								//echo"</div>";
 	                   								
 	                   								//echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Allergies:</label>";
                            						echo"<input class=\"form-control\"  name=\"allergy\" value=\"".$row4["allergy"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>";


 	                   								echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Notes:</label>";
                            						echo"<input class=\"form-control\"  name=\"notes\" value=\"".$row4["notes"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>";

 	                   								echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<input class=\"form-control\" type=\"hidden\" name=\"child_id\" value=\"".$row4["child_id"]."\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>"; 	                   								
 	                   								
 	                   								echo"<div class=\"row\">";
				                    				echo"<div class=\"col-lg-4 col-md-4\">";
				                        			echo"<div class=\"form-group\">";
				                            		echo"<center>";
				                            		echo"<br>";
				                                	echo"<input type=\"submit\" value=\"Update\" class=\"btn btn-primary\"></a>";
				                            		echo"</center>";
				                        			echo"</div>";
							                    	echo"</div>";
				                					echo"</div>";			                
			                
			                
			                
			                echo"        </div> \n";
			                echo"    </div> \n";
			                echo" </div>  \n";
			                echo"</FORM> \n";
			            
			            $x++;
						}
			            ?>
			            <div class="accordion-item">
			                    <h2 class="accordion-header">
			                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
			                            data-bs-target="#accordion<?php echo $x; ?>">  Add New Child
			                        </button>
			                    </h2>
			                    <div id="accordion<?php echo $x; ?>" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
			                        <div class="accordion-body">
													<?php			                        
													//echo "\" id=\"NewChild\">";
													echo"<h4>My new child's info</h4>";
													echo"<p>";
													echo"<FORM ACTION=\"myinfo_addchild_script.php\" METHOD=\"POST\">";
													
													echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>First Name:</label>";
                            						echo"<input class=\"form-control\" name=\"name\" value=\"\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								//echo"</div>"; 

													//echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Last Name:</label>";
                            						echo"<input class=\"form-control\" name=\"surname\" value=\"\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>"; 

 	                   								
 	                   								echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Date of Birth:</label>";
                            						echo"<input class=\"form-control\" type=\"date\" name=\"DOB\" value=\"\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								//echo"</div>";
 	                   								
 	                   								//echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Allergies:</label>";
                            						echo"<input class=\"form-control\"  name=\"allergy\" value=\"\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>";


 	                   								echo"<div class=\"row\">";
													echo"<div class=\"col-lg-6 col-md-4\">";
													echo"<div class=\"form-group\">";
                            						echo"<label>Notes:</label>";
                            						echo"<input class=\"form-control\"  name=\"notes\" value=\"\">";
                            						echo"</div>";
 	                   								echo"</div>";
 	                   								echo"</div>";
                  								
 	                   								
 	                   								echo"<div class=\"row\">";
				                    				echo"<div class=\"col-lg-4 col-md-4\">";
				                        			echo"<div class=\"form-group\">";
				                        			echo"<br>";
				                            		echo"<center>";
				                                	echo"<input type=\"submit\" value=\"Add\" class=\"btn btn-primary\"></a>";
				                            		echo"</center>";
				                        			echo"</div>";
							                    	echo"</div>";
				                					echo"</div>";
 	                   								
 	                   								echo"</form>";	                   																			
													echo"</p>";
													?>
			                        </div>
			                    </div>
			                </div>
			                
			              <!--  
			                
			                <div class="accordion-item">
			                    <h2 class="accordion-header">
			                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
			                            data-bs-target="#accordion2">
			                            Details
			                        </button>
			                    </h2>
			                    <div id="accordion2" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
			                        <div class="accordion-body">
			                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent at augue eleifend,
			                            lacinia ex quis, condimentum erat. Nullam a ipsum lorem.
			                        </div>
			                    </div>
			                </div>
			                <div class="accordion-item">
			                    <h2 class="accordion-header">
			                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
			                            data-bs-target="#accordion3">
			                            Comments
			                        </button>
			                    </h2>
			                    <div id="accordion3" class="accordion-collapse collapse" data-bs-parent="#accordionExample1">
			                        <div class="accordion-body">
			                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent at augue eleifend,
			                            lacinia ex quis, condimentum erat. Nullam a ipsum lorem.
			                        </div>
			                    </div>
			                </div>-->
			            </div>

			        </div>
                        
                        
                        

                        
                        
                        </p>
                    </li>
                    
                   <!-- reserve for youth 
                    <li class="splide__slide p-2">
                        <img src="assets/img/sample/photo/vector3.png" alt="alt" class="imaged w-100 square mb-4">
                        <h2>Great for phones & tablets</h2>
                        <p>Compatible with all mobile phones and tablet resolutions.</p>
                    </li>
                   --> 
                    
                </ul>
            </div>
        </div>
        <!-- * carousel slider -->
<!--
        <div class="carousel-button-footer">
            <div class="row">
                <div class="col-6">
                    <a href="#" class="btn btn-secondary btn-lg btn-block goBack">Go Back</a>
                </div>
                <div class="col-6">
                    <a href="app-components.html" class="btn btn-primary btn-lg btn-block">Get Started</a>
                </div>
            </div>
        </div>
-->

    </div>
    <!-- * App Capsule -->


    <!-- ============== Js Files ==============  -->
    <!-- Bootstrap -->
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- ProgressBar js -->
    <script src="assets/js/plugins/progressbar-js/progressbar.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script>

</body>

</html>