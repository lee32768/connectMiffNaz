<?php
$sCode = $_GET["code"];
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://sandbox-api.dexcom.com/v2/oauth2/token",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "client_secret=JM1FU3E7g7LkEyNF&client_id=tiSRtgkXTl7INw60TkIj9XN7sTIklHMi&code=".$sCode."&grant_type=authorization_code&redirect_uri=http://connect.miffnaz.org/CGM_Cast/returnOA.php",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
	echo "<br>";
	echo "<br>";
	echo "<br>";
	$re_array = json_decode($response,true);
	session_start();
	$_SESSION["accesstoken"] = $re_array['access_token'];
	echo $_SESSION["accesstoken"];

?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Do it</h2>
  <a href="http://connect.miffnaz.org/CGM_Cast/poll_EGVS.php" class="btn btn-info" role="button">Grab EGVS</a>
</div>

</body>
</html>