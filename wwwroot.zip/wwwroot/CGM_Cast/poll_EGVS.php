<?php
session_start();
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://sandbox-api.dexcom.com/v2/users/self/egvs?startDate=2017-06-16T15:30:00&endDate=2017-06-16T15:45:00",
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "authorization: Bearer ".$_SESSION["accesstoken"]
  ),
));
$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}

$re_array = json_decode($response,true);
	$re_value = $re_array['value'];
	
	echo "<br>";
	echo $re_value;

?>

