<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Authenticate</h2>
  <a href="https://sandbox-api.dexcom.com/v2/oauth2/login?client_id=tiSRtgkXTl7INw60TkIj9XN7sTIklHMi&redirect_uri=http://connect.miffnaz.org/CGM_Cast/returnOA.php&response_type=code&scope=offline_access&state=" class="btn btn-info" role="button">Login with Dexcom</a>
</div>

</body>
</html>